#====================================================================================================
# Get correlation between each numeric variable and the p-values corresponding to significance
# of the levels of correlation and store them in a flattened file of data element pairs and these
# two measures, in output file Correlation.xlsx in your home directory.
#
# Input file in your home directory should be nameed: Consolidated_95_Raw.xlsx
# it is downloadable from our github in the zip package: DataAnalysis
#---------------------------------------------------------------------------------------------------
#install.packages("Hmisc")  #Run these the first time...
#install.packages("xlsx")
#install.packages("tidyverse")
# ++++++++++++++++++++++++++++
# flattenCorrMatrix
# ++++++++++++++++++++++++++++
# cormat : matrix of the correlation coefficients
# pmat : matrix of the correlation p-values
flattenCorrMatrix <- function(cormat, pmat) {
  ut <- upper.tri(cormat)
  data.frame(
    row = rownames(cormat)[row(cormat)[ut]],
    column = rownames(cormat)[col(cormat)[ut]],
    cor  =(cormat)[ut],
    p = pmat[ut]
  )
}
options(max.print=1000000)
library("xlsx")
library("Hmisc")
library("dplyr")

getwd() #What is the home directory

#Read Excel File for raw data and then we will add the corrpval sheet too it...
#Read Raw data, sheet 2 with short names in line 1. Also, NA has been replaced by 0 everywhere.
Raw95 = read_xlsx("Consolidated_95_Raw.xlsx", 
                 sheet = 2, col_names = TRUE)
WaterViolation = as.factor(WaterViolation) #did not work
str(Raw95)

#Pairs plot is not working for so many, but use later to see if need to transform...
#pairs(select_if(Raw95, is.numeric)) #tried visual plot but seems to have failed.  ??? dplyr should have been enough

corr_matrix = cor(select_if(Raw95, is.numeric) , use="pairwise.complete.obs") #if non-numeric need pairwise.complete
head(corr_matrix)
#
# Stores both Correlation and p-values corresponding to significance levels of correlations
# per http://www.sthda.com/english/wiki/correlation-matrix-a-quick-start-guide-to-analyze-format-and-visualize-a-correlation-matrix-using-r-software
#res2 = rcorr(corr_matrix, type = c("pearson", "spearman"))
#Extract the correlation coefficients
#res2$r
#Extract the p-values
#res2$P

#pairwise.complete.obs needed if non numeric dat is in the matrix
res2<-rcorr(as.matrix(cor(select_if(Raw95, is.numeric) , use="pairwise.complete.obs")), type = c("pearson", "spearman"))
#Flatten from a square matrix to each pair of data elements with their correlation and p-value corresponding to significance levels of correlations
flat_matrix = flattenCorrMatrix(res2$r, res2$P)
head(flat_matrix)
openxlsx::write.xlsx(x = flat_matrix,                       # Write xlsx in R
           file = "Consolidated_95_CorPval.xlsx",
           sheetName = "CorrPvals", 
           colnames = TRUE, rownames = TRUE, append = TRUE)
